# Namoz signali (Android)

Har namoz vaqti kirganda budilnik kabi ovoz chaladi. Telefon qulflangan bo‘lsa ham qulf ekranida soat va namoz nomi (masalan, “Peshin”) chiqadi. “O‘CHIRISH” tugmasi bosilmaguncha ovoz takrorlanadi.

## APK ni olish (Android Studio shart emas)

1. github.com da bepul akkaunt oching va yangi repozitoriy yarating (nomi: `namoz-signali`, Public yoki Private).
2. Repozitoriy sahifasida **Add file → Upload files** ni bosing va shu zip ichidagi hamma narsani (`app` papkasi, `.github` papkasi, `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`) sudrab tashlang. **Commit changes** ni bosing.
   - `.github` papkasi ko‘rinmasa: **Add file → Create new file**, nomiga `.github/workflows/build.yml` deb yozing va shu fayl matnini joylang.
3. **Actions** bo‘limiga kiring. “APK yig‘ish” avtomatik ishga tushadi (taxminan 3–5 daqiqa). Agar ishlamasa, uni tanlab **Run workflow** ni bosing.
4. Yashil belgi chiqqach, ishga tushirilgan yozuvni oching, pastdagi **Artifacts** bo‘limidan `namoz-signali-apk` ni yuklab oling. Zip ichida `app-debug.apk` bor.
5. APK ni telefonda oching. Telefon “noma’lum manba”dan o‘rnatishga ruxsat so‘rasa, ruxsat bering.

## Birinchi ishga tushirish

Ilovada **Ruxsatlarni sozlash** tugmasini ketma-ket bosing. U navbat bilan so‘raydi:

1. Bildirishnoma
2. Aniq vaqtli signal
3. Qulf ekranida ko‘rsatish
4. Batareya cheklovisiz ishlash

So‘ng **Signalni sinab ko‘rish** tugmasi bilan tekshiring. Xiaomi, Huawei, Samsung kabi telefonlarda “Avto-ishga tushirish” yoki “Batareya tejash” sozlamasidan ilovani istisno qilish ham kerak bo‘lishi mumkin.

## Oldindan chalish

“Oldindan chalish” bo‘limida namoz vaqtidan necha daqiqa oldin signal chalinishini o‘zingiz yozasiz (masalan, 10). Tez tanlash uchun “Vaqtida”, 5, 10, 15 tugmalari bor. Signal oynasida “Namoz vaqtiga 10 daqiqa qoldi” deb yoziladi. Agar oldindan chalish vaqti allaqachon o‘tib ketgan bo‘lsa (masalan, Asrga 5 daqiqa qolganda 10 daqiqa oldin qo‘ysangiz), shu namoz o‘tkazib yuboriladi va keyingisi qo‘yiladi.

Ilova yoshi kattalar uchun katta harflar, baland kontrast va katta tugmalar bilan yaratilgan.

## Namoz vaqtini qo‘lda kiritish

Ro‘yxatdagi istalgan namoz vaqti ustiga bossangiz, soat tanlash oynasi ochiladi. Tanlangan vaqt har kuni shu soatda saqlanadi va yashil rangda “(qo‘lda)” belgisi bilan ko‘rinadi. Avtomatik hisoblashga qaytish uchun shu oynadagi **Avtomatik** tugmasini bosing. Oldindan chalish ham qo‘lda kiritilgan vaqtga nisbatan ishlaydi.

## Joylashuv va vaqtlar

Namoz vaqtlari har kuni sanadan va joylashuvdan qayta hisoblanadi, shuning uchun ular kundan-kunga o‘zgaradi. Ro‘yxatning birinchi qatori “Joylashuvim (avtomatik)”: uni tanlasangiz, ilova joylashuv ruxsatini so‘raydi va vaqtlarni turgan joyingiz bo‘yicha hisoblaydi. Soat mintaqasi telefondan olinadi. Ilova ochilganda joylashuv yangilanadi, ilova yopiq paytda yangilanmaydi. Xohlasangiz, ro‘yxatdan shaharni qo‘lda tanlash ham mumkin.

## Ovoz

Ilovada ikki yo‘l bor: telefon ovozlaridan tanlash yoki telefondagi audio fayldan (masalan, azon yozuvi). Qisqa ovoz takrorlanadi, uzun fayl to‘liq chalinadi.

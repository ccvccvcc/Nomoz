package uz.namoz.signal

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView

/** Qulf ekranida chiqadigan signal oynasi: soat, namoz nomi va "O‘chirish" tugmasi. */
class AlarmActivity : Activity() {

    private val closer = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            finish()
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val name = intent.getStringExtra("name") ?: "Namoz"
        val time = intent.getStringExtra("time") ?: ""
        val early = intent.getIntExtra("early", 0)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(Color.parseColor("#0B1A1F"))
            setPadding(dp(24), dp(72), dp(24), dp(48))
        }

        val clock = TextClock(this).apply {
            format24Hour = "HH:mm"
            format12Hour = "HH:mm"
            textSize = 96f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            gravity = Gravity.CENTER
        }
        root.addView(clock)

        val title = TextView(this).apply {
            text = name
            textSize = 64f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.parseColor("#4CC2A5"))
            gravity = Gravity.CENTER
            setPadding(0, dp(24), 0, 0)
        }
        root.addView(title)

        val sub = TextView(this).apply {
            text = Scheduler.subtitle(time, early)
            textSize = 26f
            setTextColor(Color.parseColor("#D5E0E2"))
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
        }
        root.addView(sub)

        val spacer = View(this)
        root.addView(spacer, LinearLayout.LayoutParams(0, 0, 1f))

        val stop = Button(this).apply {
            text = "O‘CHIRISH"
            textSize = 34f
            setTextColor(Color.parseColor("#0B1A1F"))
            setBackgroundColor(Color.WHITE)
            setOnClickListener {
                startService(
                    Intent(this@AlarmActivity, AlarmService::class.java)
                        .setAction(AlarmService.ACTION_STOP)
                )
                finish()
            }
        }
        root.addView(
            stop,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(160))
        )

        setContentView(root)

        val filter = IntentFilter(AlarmService.ACTION_DISMISSED)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(closer, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(closer, filter)
        }
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(closer)
        } catch (e: Exception) {
        }
        super.onDestroy()
    }
}

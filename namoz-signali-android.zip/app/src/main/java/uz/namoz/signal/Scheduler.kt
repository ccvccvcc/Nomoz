package uz.namoz.signal

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.time.Instant
import java.time.LocalDate
import java.time.format.DateTimeFormatter

object Scheduler {
    fun format(ms: Long): String =
        DateTimeFormatter.ofPattern("HH:mm").withZone(Prayers.ZONE).format(Instant.ofEpochMilli(ms))

    fun subtitle(time: String, early: Int): String =
        if (early > 0) "Namoz vaqtiga $early daqiqa qoldi · $time" else "Namoz vaqti · $time"

    /** Signal chalinadigan vaqt: namoz vaqtidan "oldindan" daqiqa oldin. */
    fun triggerAt(ctx: Context, e: Prayers.Entry): Long = e.at - Prefs.early(ctx) * 60000L

    /** Berilgan kun uchun vaqtlar: qo‘lda kiritilgani bo‘lsa shu, aks holda avtomatik hisoblangani. */
    fun entries(ctx: Context, date: LocalDate): List<Prayers.Entry> {
        val auto = Prayers.forDate(date, Prefs.city(ctx)).associateBy { it.key }
        val out = ArrayList<Prayers.Entry>()
        for (k in Prayers.KEYS) {
            val m = Prefs.manual(ctx, k)
            if (m >= 0) {
                val at = date.atStartOfDay(Prayers.ZONE).plusMinutes(m.toLong()).toInstant().toEpochMilli()
                out.add(Prayers.Entry(k, Prayers.NAMES.getValue(k), at))
            } else {
                auto[k]?.let { out.add(it) }
            }
        }
        return out
    }

    /** Hozirdan keyin signal chalinadigan keyingi namoz. */
    fun next(ctx: Context): Prayers.Entry? {
        val now = System.currentTimeMillis()
        val today = LocalDate.now(Prayers.ZONE)
        for (d in 0..2) {
            val list = entries(ctx, today.plusDays(d.toLong()))
                .filter { Prefs.enabled(ctx, it.key) && triggerAt(ctx, it) > now + 1000 }
            if (list.isNotEmpty()) return list.minByOrNull { it.at }
        }
        return null
    }

    private fun alarmIntent(ctx: Context, e: Prayers.Entry): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java)
            .putExtra("name", e.name)
            .putExtra("time", format(e.at))
            .putExtra("early", Prefs.early(ctx))
        return PendingIntent.getBroadcast(
            ctx, 1001, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /** Keyingi signalni qo‘yadi. Eskisi avtomatik almashadi. */
    fun scheduleNext(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val e = next(ctx)
        if (e == null) {
            val probe = Intent(ctx, AlarmReceiver::class.java)
            val pi = PendingIntent.getBroadcast(
                ctx, 1001, probe, PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )
            if (pi != null) am.cancel(pi)
            return
        }
        val trigger = triggerAt(ctx, e)
        val pi = alarmIntent(ctx, e)
        val show = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val canExact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
        if (canExact) {
            am.setAlarmClock(AlarmManager.AlarmClockInfo(trigger, show), pi)
        } else {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
        }
    }
}

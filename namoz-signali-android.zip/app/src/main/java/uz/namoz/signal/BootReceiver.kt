package uz.namoz.signal

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Telefon qayta yoqilganda yoki vaqt o‘zgarganda signalni qayta qo‘yadi. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Scheduler.scheduleNext(context)
    }
}

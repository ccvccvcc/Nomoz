package uz.namoz.signal

import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.tan

/** Namoz vaqtlarini quyosh holatidan hisoblaydi (Musulmon dunyosi ligasi, Asr: Hanafiy). */
object Prayers {
    /** Telefonning joriy soat mintaqasi. */
    val ZONE: ZoneId get() = ZoneId.systemDefault()
    val KEYS = listOf("fajr", "sunrise", "dhuhr", "asr", "maghrib", "isha")
    val NAMES = mapOf(
        "fajr" to "Bomdod",
        "sunrise" to "Quyosh",
        "dhuhr" to "Peshin",
        "asr" to "Asr",
        "maghrib" to "Shom",
        "isha" to "Xufton"
    )

    class City(val name: String, val lat: Double, val lng: Double)
    class Entry(val key: String, val name: String, val at: Long)

    val CITIES = listOf(
        City("Toshkent", 41.311, 69.279),
        City("Samarqand", 39.654, 66.976),
        City("Buxoro", 39.768, 64.421),
        City("Andijon", 40.783, 72.344),
        City("Namangan", 40.998, 71.673),
        City("Farg‘ona", 40.384, 71.784),
        City("Qo‘qon", 40.529, 70.943),
        City("Jizzax", 40.115, 67.842),
        City("Guliston", 40.489, 68.784),
        City("Navoiy", 40.103, 65.374),
        City("Qarshi", 38.861, 65.789),
        City("Termiz", 37.224, 67.278),
        City("Urganch", 41.550, 60.633),
        City("Xiva", 41.378, 60.364),
        City("Nukus", 42.460, 59.603)
    )

    private fun rad(d: Double) = d * PI / 180.0
    private fun deg(r: Double) = r * 180.0 / PI

    private fun fix(a: Double, b: Double): Double {
        val x = a - b * floor(a / b)
        return if (x < 0) x + b else x
    }

    private fun julian(year: Int, month: Int, day: Int): Double {
        var y = year
        var m = month
        if (m <= 2) {
            y -= 1
            m += 12
        }
        val a = floor(y / 100.0)
        val b = 2 - a + floor(a / 4.0)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + day + b - 1524.5
    }

    private class Sun(val decl: Double, val eqt: Double)

    private fun sunPos(jd: Double): Sun {
        val d = jd - 2451545.0
        val g = fix(357.529 + 0.98560028 * d, 360.0)
        val q = fix(280.459 + 0.98564736 * d, 360.0)
        val l = fix(q + 1.915 * sin(rad(g)) + 0.020 * sin(rad(2 * g)), 360.0)
        val e = 23.439 - 0.00000036 * d
        val ra = fix(deg(atan2(cos(rad(e)) * sin(rad(l)), cos(rad(l)))) / 15.0, 24.0)
        return Sun(deg(asin(sin(rad(e)) * sin(rad(l)))), q / 15.0 - ra)
    }

    /** Mahalliy soat bilan (0..24) oltita vaqt. */
    private fun hours(date: LocalDate, city: City): Map<String, Double> {
        val tz = ZONE.rules.getOffset(date.atTime(12, 0)).totalSeconds / 3600.0
        val jd = julian(date.year, date.monthValue, date.dayOfMonth) - city.lng / (15.0 * 24.0)

        fun midDay(t: Double): Double = fix(12.0 - sunPos(jd + t).eqt, 24.0)

        fun angleTime(angle: Double, t: Double, ccw: Boolean): Double {
            val decl = sunPos(jd + t).decl
            val noon = midDay(t)
            val x = (-sin(rad(angle)) - sin(rad(decl)) * sin(rad(city.lat))) /
                (cos(rad(decl)) * cos(rad(city.lat)))
            if (x > 1.0 || x < -1.0) return Double.NaN
            val v = deg(acos(x)) / 15.0
            return if (ccw) noon - v else noon + v
        }

        fun asrTime(factor: Double, t: Double): Double {
            val decl = sunPos(jd + t).decl
            val angle = -deg(atan(1.0 / (factor + tan(rad(abs(city.lat - decl))))))
            return angleTime(angle, t, false)
        }

        var t = mapOf(
            "fajr" to 5.0, "sunrise" to 6.0, "dhuhr" to 12.0,
            "asr" to 13.0, "maghrib" to 18.0, "isha" to 18.0
        )
        repeat(2) {
            val p = t.mapValues { it.value / 24.0 }
            t = mapOf(
                "fajr" to angleTime(18.0, p.getValue("fajr"), true),
                "sunrise" to angleTime(0.833, p.getValue("sunrise"), true),
                "dhuhr" to midDay(p.getValue("dhuhr")),
                "asr" to asrTime(2.0, p.getValue("asr")),
                "maghrib" to angleTime(0.833, p.getValue("maghrib"), false),
                "isha" to angleTime(17.0, p.getValue("isha"), false)
            )
        }
        val shift = tz - city.lng / 15.0
        return t.mapValues { it.value + shift }
    }

    fun forDate(date: LocalDate, city: City): List<Entry> {
        val h = hours(date, city)
        val base = date.atStartOfDay(ZONE).toInstant().toEpochMilli()
        val out = ArrayList<Entry>()
        for (k in KEYS) {
            val v = h[k] ?: continue
            if (v.isNaN()) continue
            val at = Math.round((base + v * 3600000.0) / 60000.0) * 60000L
            out.add(Entry(k, NAMES.getValue(k), at))
        }
        return out
    }
}

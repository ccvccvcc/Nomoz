package uz.namoz.signal

import android.content.Context
import android.net.Uri

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("namoz", Context.MODE_PRIVATE)

    /** Qo‘lda tanlangan shahar nomi. */
    fun cityName(c: Context): String = sp(c).getString("city", "Samarqand") ?: "Samarqand"

    fun useGps(c: Context): Boolean = sp(c).getBoolean("gps", false) && sp(c).contains("lat")

    /** Hisoblash uchun joy: avtomatik joylashuv yoki tanlangan shahar. */
    fun city(c: Context): Prayers.City {
        if (useGps(c)) {
            val lat = sp(c).getString("lat", null)?.toDoubleOrNull()
            val lng = sp(c).getString("lng", null)?.toDoubleOrNull()
            if (lat != null && lng != null) return Prayers.City("Joylashuvim", lat, lng)
        }
        return Prayers.CITIES.firstOrNull { it.name == cityName(c) } ?: Prayers.CITIES[1]
    }

    fun placeLabel(c: Context): String {
        if (!useGps(c)) return cityName(c)
        val p = city(c)
        return "Joylashuvim (%.2f, %.2f)".format(p.lat, p.lng)
    }

    fun setCity(c: Context, name: String) {
        sp(c).edit().putString("city", name).putBoolean("gps", false).apply()
    }

    fun setGps(c: Context, lat: Double, lng: Double) {
        sp(c).edit().putString("lat", lat.toString()).putString("lng", lng.toString()).putBoolean("gps", true).apply()
    }

    /** Namoz vaqtidan necha daqiqa oldin signal chalinishi (0 dan 180 gacha). */
    fun early(c: Context): Int = sp(c).getInt("early", 0).coerceIn(0, 180)

    fun setEarly(c: Context, minutes: Int) {
        sp(c).edit().putInt("early", minutes.coerceIn(0, 180)).apply()
    }

    /** Qo‘lda kiritilgan namoz vaqti (kun boshidan daqiqalarda). Kiritilmagan bo‘lsa -1. */
    fun manual(c: Context, key: String): Int = sp(c).getInt("manual_$key", -1)

    /** minutes < 0 bo‘lsa, qo‘lda kiritilgan vaqt o‘chiriladi (avtomatik hisoblashga qaytadi). */
    fun setManual(c: Context, key: String, minutes: Int) {
        val e = sp(c).edit()
        if (minutes < 0) e.remove("manual_$key") else e.putInt("manual_$key", minutes.coerceIn(0, 1439))
        e.apply()
    }

    fun enabled(c: Context, key: String): Boolean = sp(c).getBoolean("on_$key", key != "sunrise")

    fun setEnabled(c: Context, key: String, on: Boolean) {
        sp(c).edit().putBoolean("on_$key", on).apply()
    }

    fun sound(c: Context): Uri? = sp(c).getString("sound", null)?.let { Uri.parse(it) }

    fun soundLabel(c: Context): String = sp(c).getString("sound_label", "Standart signal") ?: "Standart signal"

    fun setSound(c: Context, uri: Uri?, label: String) {
        sp(c).edit().putString("sound", uri?.toString()).putString("sound_label", label).apply()
    }
}

package uz.namoz.signal

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Vaqti kelganda signalni boshlaydi va keyingisini qo‘yadi. */
class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val i = Intent(context, AlarmService::class.java)
            .putExtra("name", intent.getStringExtra("name"))
            .putExtra("time", intent.getStringExtra("time"))
            .putExtra("early", intent.getIntExtra("early", 0))
        try {
            context.startForegroundService(i)
        } catch (e: Exception) {
            // Tizim ishga tushirishga ruxsat bermasa, keyingi signal baribir qo‘yiladi.
        }
        Scheduler.scheduleNext(context)
    }
}

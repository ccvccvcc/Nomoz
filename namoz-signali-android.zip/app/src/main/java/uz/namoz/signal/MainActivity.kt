package uz.namoz.signal

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.NotificationManager
import android.app.TimePickerDialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Looper
import android.os.PowerManager
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.time.Instant
import java.time.LocalDate

/**
 * Asosiy oyna. Katta harflar, baland kontrast va katta tugmalar bilan yoshi kattalar uchun moslangan.
 */
class MainActivity : Activity() {

    private val BG = Color.parseColor("#F4F7F7")
    private val INK = Color.parseColor("#0A1A1F")
    private val MUTED = Color.parseColor("#3A4D52")
    private val ACCENT = Color.parseColor("#0B5A4C")
    private val WARN = Color.parseColor("#9A2F1B")
    private val LINE = Color.parseColor("#9AA9AD")
    private val OFF = Color.parseColor("#D5DDDF")

    private val toggles = HashMap<String, Button>()
    private val timeViews = HashMap<String, TextView>()
    private val nameViews = HashMap<String, TextView>()
    private lateinit var dateView: TextView
    private lateinit var nextTime: TextView
    private lateinit var nextSub: TextView
    private lateinit var soundView: TextView
    private lateinit var statusView: TextView
    private lateinit var earlyInput: EditText
    private lateinit var spinner: Spinner
    private var shownIndex = 0

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun shape(color: Int, radius: Int = 14): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
        }

    private fun tv(t: String, size: Float, color: Int = INK, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = t
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun bigButton(t: String, bg: Int, fg: Int, onClick: () -> Unit): Button =
        Button(this).apply {
            text = t
            textSize = 21f
            isAllCaps = false
            setTextColor(fg)
            background = shape(bg)
            minHeight = dp(68)
            minimumHeight = dp(68)
            setOnClickListener { onClick() }
        }

    private fun lp(top: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(top) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(BG)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(44))
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(tv("Namoz signali", 36f, INK, true))
        dateView = tv("", 20f, MUTED)
        root.addView(dateView, lp(4))

        // Keyingi signal
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = shape(ACCENT, 18)
            setPadding(dp(20), dp(18), dp(20), dp(20))
        }
        card.addView(tv("Keyingi signal", 20f, Color.WHITE))
        nextTime = tv("--:--", 56f, Color.WHITE, true)
        card.addView(nextTime)
        nextSub = tv("", 20f, Color.WHITE)
        card.addView(nextSub)
        root.addView(card, lp(16))

        // Bugungi vaqtlar
        root.addView(tv("Bugungi namoz vaqtlari", 24f, INK, true), lp(30))
        root.addView(tv("Vaqtni o‘zingiz kiritish uchun vaqt ustiga bosing.", 18f, MUTED), lp(4))
        for (key in Prayers.KEYS) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(14), 0, dp(14))
            }
            val nameV = tv(Prayers.NAMES.getValue(key), 26f)
            nameViews[key] = nameV
            row.addView(
                nameV,
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            )
            val t = tv("--:--", 36f, INK, true)
            t.setPadding(0, dp(8), dp(14), dp(8))
            t.setOnClickListener { editTime(key) }
            timeViews[key] = t
            row.addView(t)

            val b = Button(this).apply {
                isAllCaps = false
                textSize = 18f
                minWidth = dp(112)
                minimumWidth = dp(112)
                minHeight = dp(60)
                minimumHeight = dp(60)
                setOnClickListener {
                    Prefs.setEnabled(this@MainActivity, key, !Prefs.enabled(this@MainActivity, key))
                    styleToggle(key)
                    Scheduler.scheduleNext(this@MainActivity)
                    refresh()
                }
            }
            toggles[key] = b
            styleToggle(key)
            row.addView(b)
            root.addView(row)
            root.addView(View(this).apply { setBackgroundColor(LINE) },
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1)))
        }

        // Oldindan chalish
        root.addView(tv("Oldindan chalish", 24f, INK, true), lp(34))
        root.addView(tv("Namoz vaqtidan necha daqiqa oldin signal chalsin?", 20f, MUTED), lp(6))
        val erow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        earlyInput = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            imeOptions = EditorInfo.IME_ACTION_DONE
            setSingleLine(true)
            filters = arrayOf<InputFilter>(InputFilter.LengthFilter(3))
            textSize = 34f
            setTextColor(INK)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                setStroke(dp(2), LINE)
                cornerRadius = dp(12).toFloat()
            }
            setPadding(dp(8), dp(10), dp(8), dp(10))
            setText(Prefs.early(this@MainActivity).toString())
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    val v = s?.toString()?.toIntOrNull() ?: 0
                    Prefs.setEarly(this@MainActivity, v)
                    Scheduler.scheduleNext(this@MainActivity)
                    refresh()
                }
            })
        }
        erow.addView(earlyInput, LinearLayout.LayoutParams(dp(130), LinearLayout.LayoutParams.WRAP_CONTENT))
        val erowLabel = tv("daqiqa oldin", 22f)
        erowLabel.setPadding(dp(14), 0, 0, 0)
        erow.addView(erowLabel)
        root.addView(erow, lp(12))

        val quick = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((label, v) in listOf("Vaqtida" to 0, "5" to 5, "10" to 10, "15" to 15)) {
            val qb = Button(this).apply {
                text = label
                textSize = 20f
                isAllCaps = false
                setTextColor(INK)
                background = shape(OFF, 12)
                minHeight = dp(60)
                minimumHeight = dp(60)
                minWidth = 0
                minimumWidth = 0
                setOnClickListener { earlyInput.setText(v.toString()) }
            }
            val p = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            p.rightMargin = dp(8)
            quick.addView(qb, p)
        }
        root.addView(quick, lp(12))
        root.addView(tv("0 yozsangiz, aynan namoz vaqtida chalinadi. Eng ko‘pi 180 daqiqa.", 18f, MUTED), lp(8))

        // Ovoz
        root.addView(tv("Signal ovozi", 24f, INK, true), lp(34))
        soundView = tv("", 20f, MUTED)
        root.addView(soundView, lp(4))
        root.addView(bigButton("Telefon ovozlaridan tanlash", ACCENT, Color.WHITE) { pickSystemSound() }, lp(10))
        root.addView(bigButton("Telefondagi fayldan tanlash", OFF, INK) { pickFile() }, lp(10))

        // Joylashuv
        root.addView(tv("Qayerda turibsiz?", 24f, INK, true), lp(34))
        root.addView(tv("Namoz vaqtlari shu joyga qarab hisoblanadi.", 18f, MUTED), lp(4))
        spinner = Spinner(this)
        val items = listOf("Joylashuvim (avtomatik)") + Prayers.CITIES.map { it.name }
        val adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, items) {
            private fun style(v: View): View {
                (v as? TextView)?.apply {
                    textSize = 22f
                    setTextColor(INK)
                    setPadding(dp(12), dp(16), dp(12), dp(16))
                }
                return v
            }

            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View =
                style(super.getView(position, convertView, parent))

            override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View =
                style(super.getDropDownView(position, convertView, parent))
        }
        spinner.adapter = adapter
        shownIndex = spinnerIndex()
        spinner.setSelection(shownIndex)
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                if (pos == shownIndex) return
                shownIndex = pos
                if (pos == 0) {
                    detectLocation()
                } else {
                    Prefs.setCity(this@MainActivity, Prayers.CITIES[pos - 1].name)
                    Scheduler.scheduleNext(this@MainActivity)
                    refresh()
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        root.addView(spinner, lp(8))

        // Ruxsatlar
        root.addView(tv("Ruxsatlar", 24f, INK, true), lp(34))
        statusView = tv("", 20f, MUTED)
        root.addView(statusView, lp(6))
        root.addView(bigButton("Ruxsatlarni sozlash", ACCENT, Color.WHITE) { nextPermissionStep() }, lp(12))
        root.addView(bigButton("Signalni sinab ko‘rish", OFF, INK) { testAlarm() }, lp(10))
    }

    override fun onResume() {
        super.onResume()
        // Avtomatik rejimda ilova ochilganda joylashuv jim yangilanadi (sayohat qilsangiz ham).
        if (Prefs.useGps(this) && locationOk()) lastKnown()?.let { applyLocation(it, false) }
        Scheduler.scheduleNext(this)
        refresh()
    }

    /** Namoz vaqtini qo‘lda kiritish oynasi. "Avtomatik" tugmasi avtomatik hisoblashga qaytaradi. */
    private fun editTime(key: String) {
        val cur = Scheduler.entries(this, LocalDate.now(Prayers.ZONE)).firstOrNull { it.key == key }
        val z = cur?.let { Instant.ofEpochMilli(it.at).atZone(Prayers.ZONE) }
        val dialog = TimePickerDialog(
            this,
            { _, h, m ->
                Prefs.setManual(this, key, h * 60 + m)
                Scheduler.scheduleNext(this)
                refresh()
            },
            z?.hour ?: 12, z?.minute ?: 0, true
        )
        dialog.setTitle(Prayers.NAMES.getValue(key) + " vaqti")
        dialog.setButton(DialogInterface.BUTTON_NEUTRAL, "Avtomatik") { _, _ ->
            Prefs.setManual(this, key, -1)
            Scheduler.scheduleNext(this)
            refresh()
        }
        dialog.show()
    }

    private fun styleToggle(key: String) {
        val b = toggles[key] ?: return
        val on = Prefs.enabled(this, key)
        b.text = if (on) "YOQIQ" else "O‘CHIQ"
        b.background = shape(if (on) ACCENT else OFF, 12)
        b.setTextColor(if (on) Color.WHITE else INK)
    }

    private fun spinnerIndex(): Int =
        if (Prefs.useGps(this)) 0
        else 1 + Prayers.CITIES.indexOfFirst { it.name == Prefs.cityName(this) }.coerceAtLeast(0)

    private fun syncSpinner() {
        val idx = spinnerIndex()
        if (idx != shownIndex) {
            shownIndex = idx
            spinner.setSelection(idx)
        }
    }

    private fun refresh() {
        val today = LocalDate.now(Prayers.ZONE)
        dateView.text = "${today.dayOfMonth}.${"%02d".format(today.monthValue)}.${today.year} · ${Prefs.placeLabel(this)}"
        syncSpinner()
        for (e in Scheduler.entries(this, today)) {
            val manual = Prefs.manual(this, e.key) >= 0
            timeViews[e.key]?.apply {
                text = Scheduler.format(e.at)
                setTextColor(if (manual) ACCENT else INK)
            }
            nameViews[e.key]?.text = if (manual) e.name + "\n(qo‘lda)" else e.name
        }
        val n = Scheduler.next(this)
        if (n != null) {
            val early = Prefs.early(this)
            val trigger = Scheduler.triggerAt(this, n)
            val tomorrow = Instant.ofEpochMilli(trigger).atZone(Prayers.ZONE).toLocalDate() != today
            nextTime.text = Scheduler.format(trigger)
            nextSub.text = n.name + " vaqti " + Scheduler.format(n.at) +
                (if (tomorrow) " (ertaga)" else "") +
                (if (early > 0) ". $early daqiqa oldin chaladi." else "")
        } else {
            nextTime.text = "--:--"
            nextSub.text = "Hech bir signal yoqilmagan"
        }
        soundView.text = Prefs.soundLabel(this)

        val missing = ArrayList<String>()
        if (!notificationsOk()) missing.add("Bildirishnoma")
        if (!exactOk()) missing.add("Aniq vaqtli signal")
        if (!fullScreenOk()) missing.add("Qulf ekranida ko‘rsatish")
        if (!batteryOk()) missing.add("Batareya cheklovini olib tashlash")
        if (missing.isEmpty()) {
            statusView.text = "Hammasi tayyor. Signal ishlaydi."
            statusView.setTextColor(ACCENT)
        } else {
            statusView.text = "Hali yoqilmagan:\n• " + missing.joinToString("\n• ") +
                "\n\n“Ruxsatlarni sozlash” tugmasini bosing."
            statusView.setTextColor(WARN)
        }
    }

    private fun notificationsOk() =
        Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun exactOk() =
        Build.VERSION.SDK_INT < 31 ||
            (getSystemService(Context.ALARM_SERVICE) as AlarmManager).canScheduleExactAlarms()

    private fun fullScreenOk() =
        Build.VERSION.SDK_INT < 34 ||
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).canUseFullScreenIntent()

    private fun batteryOk() =
        (getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)

    private fun locationOk() =
        checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    /** Yetishmayotgan ruxsatni birin-ketin so‘raydi. */
    private fun nextPermissionStep() {
        val pkg = Uri.parse("package:$packageName")
        when {
            !notificationsOk() ->
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            !exactOk() ->
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, pkg))
            !fullScreenOk() ->
                startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, pkg))
            !batteryOk() ->
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkg))
            else ->
                Toast.makeText(this, "Hamma ruxsat berilgan", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (code == 2) {
            if (locationOk()) detectLocation() else {
                Toast.makeText(this, "Joylashuv ruxsati berilmadi", Toast.LENGTH_SHORT).show()
                syncSpinner()
            }
            return
        }
        refresh()
    }

    private fun lastKnown(): Location? {
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        var best: Location? = null
        for (p in lm.getProviders(true)) {
            val l = try {
                lm.getLastKnownLocation(p)
            } catch (e: SecurityException) {
                null
            }
            if (l != null && (best == null || l.time > best.time)) best = l
        }
        return best
    }

    private fun applyLocation(l: Location, announce: Boolean) {
        Prefs.setGps(this, l.latitude, l.longitude)
        Scheduler.scheduleNext(this)
        refresh()
        if (announce) Toast.makeText(this, "Joylashuv aniqlandi", Toast.LENGTH_SHORT).show()
    }

    /** Joylashuvni aniqlaydi. Aniqlanmasa, oldingi shaharga qaytadi. */
    @Suppress("DEPRECATION")
    private fun detectLocation() {
        if (!locationOk()) {
            requestPermissions(
                arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION), 2
            )
            return
        }
        val known = lastKnown()
        if (known != null) {
            applyLocation(known, true)
            return
        }
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val provider = when {
            lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
            lm.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
            else -> null
        }
        if (provider == null) {
            Toast.makeText(this, "Telefon sozlamalarida joylashuvni yoqing", Toast.LENGTH_LONG).show()
            syncSpinner()
            return
        }
        Toast.makeText(this, "Joylashuv aniqlanmoqda…", Toast.LENGTH_SHORT).show()
        try {
            lm.requestSingleUpdate(provider, object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    applyLocation(location, true)
                }

                override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
                override fun onProviderEnabled(provider: String) {}
                override fun onProviderDisabled(provider: String) {}
            }, Looper.getMainLooper())
        } catch (e: SecurityException) {
            syncSpinner()
        }
    }

    private fun testAlarm() {
        val i = Intent(this, AlarmService::class.java)
            .putExtra("name", "Sinov")
            .putExtra("time", Scheduler.format(System.currentTimeMillis()))
            .putExtra("early", 0)
        startForegroundService(i)
    }

    private fun pickSystemSound() {
        val i = Intent(RingtoneManager.ACTION_RINGTONE_PICKER)
            .putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
            .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
            .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
            .putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Prefs.sound(this))
        startActivityForResult(i, 11)
    }

    private fun pickFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType("audio/*")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        startActivityForResult(i, 12)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        when (requestCode) {
            11 -> {
                val uri = data.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
                val title = if (uri == null) "Standart signal" else try {
                    RingtoneManager.getRingtone(this, uri)?.getTitle(this) ?: "Tanlangan ovoz"
                } catch (e: Exception) {
                    "Tanlangan ovoz"
                }
                Prefs.setSound(this, uri, title)
            }
            12 -> {
                val uri = data.data ?: return
                try {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (e: Exception) {
                }
                var title: String? = null
                try {
                    contentResolver.query(uri, null, null, null, null)?.use { c ->
                        val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (idx >= 0 && c.moveToFirst()) title = c.getString(idx)
                    }
                } catch (e: Exception) {
                }
                Prefs.setSound(this, uri, title ?: "Tanlangan fayl")
            }
        }
        refresh()
    }
}
